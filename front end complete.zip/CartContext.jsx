// context/CartContext.jsx
// Manages the shopping cart: add, remove, update quantity, clear, persist.
// Cart is stored in localStorage so it survives page refresh.

import { createContext, useContext, useState, useCallback } from "react";

const CartContext = createContext(null);

const loadCartFromStorage = () => {
  try {
    const stored = localStorage.getItem("cart");
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

const saveCartToStorage = (items) => {
  localStorage.setItem("cart", JSON.stringify(items));
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(loadCartFromStorage);

  // ── Internal updater — always syncs to localStorage ────────────────────────
  const updateCart = useCallback((updaterFn) => {
    setCartItems((prev) => {
      const next = updaterFn(prev);
      saveCartToStorage(next);
      return next;
    });
  }, []);

  // ── addToCart ──────────────────────────────────────────────────────────────
  // If the product already exists in the cart, increment its quantity.
  // Respects the product's stock ceiling.
  const addToCart = useCallback(
    (product, quantity = 1) => {
      updateCart((prev) => {
        const existing = prev.find((item) => item._id === product._id);
        if (existing) {
          return prev.map((item) =>
            item._id === product._id
              ? {
                  ...item,
                  quantity: Math.min(item.quantity + quantity, product.stock),
                }
              : item
          );
        }
        return [...prev, { ...product, quantity: Math.min(quantity, product.stock) }];
      });
    },
    [updateCart]
  );

  // ── removeFromCart ─────────────────────────────────────────────────────────
  const removeFromCart = useCallback(
    (productId) => {
      updateCart((prev) => prev.filter((item) => item._id !== productId));
    },
    [updateCart]
  );

  // ── updateQuantity ─────────────────────────────────────────────────────────
  // Setting quantity to 0 or below removes the item.
  const updateQuantity = useCallback(
    (productId, quantity) => {
      if (quantity <= 0) {
        removeFromCart(productId);
        return;
      }
      updateCart((prev) =>
        prev.map((item) =>
          item._id === productId ? { ...item, quantity } : item
        )
      );
    },
    [updateCart, removeFromCart]
  );

  // ── clearCart ──────────────────────────────────────────────────────────────
  const clearCart = useCallback(() => {
    updateCart(() => []);
  }, [updateCart]);

  // ── Derived values ─────────────────────────────────────────────────────────
  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const value = {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    totalItems,
    totalPrice,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

// ── Custom hook ───────────────────────────────────────────────────────────────
export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside <CartProvider>");
  return context;
};
