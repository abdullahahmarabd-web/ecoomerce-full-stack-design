// pages/Login.jsx
// Single page with Login / Register tab toggle.
// On success, calls AuthContext.login() and redirects to intended page or /.

import { useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Where to redirect after login (set by ProtectedRoute)
  const from = location.state?.from?.pathname || "/";

  // If already logged in, redirect immediately
  if (isAuthenticated) {
    navigate(from, { replace: true });
  }

  const [tab, setTab] = useState("login"); // "login" | "register"
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Form fields
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setError(""); // clear error on input
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const endpoint = tab === "login" ? "/api/auth/login" : "/api/auth/register";
      const payload =
        tab === "login"
          ? { email: form.email, password: form.password }
          : { name: form.name, email: form.email, password: form.password };

      const { data } = await axios.post(endpoint, payload);
      login(data);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          {/* Tab toggle */}
          <div className="grid grid-cols-2 border-b border-slate-200">
            {["login", "register"].map((t) => (
              <button
                key={t}
                onClick={() => { setTab(t); setError(""); }}
                className={`py-4 text-sm font-semibold capitalize transition-colors ${
                  tab === t
                    ? "text-brand-600 border-b-2 border-brand-600 bg-brand-50/50"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="p-8">
            <h1 className="text-2xl font-bold text-slate-900 mb-1">
              {tab === "login" ? "Welcome back" : "Create an account"}
            </h1>
            <p className="text-sm text-slate-400 mb-6">
              {tab === "login"
                ? "Sign in to access your cart and orders."
                : "Join ShopMERN to start shopping."}
            </p>

            {/* Error banner */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3 mb-5">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {tab === "register" && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">
                    Full Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    required
                    placeholder="John Doe"
                    className="form-input"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                  placeholder="you@example.com"
                  className="form-input"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  required
                  minLength={6}
                  placeholder="Min. 6 characters"
                  className="form-input"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-3 text-base mt-2"
              >
                {loading
                  ? "Please wait..."
                  : tab === "login"
                  ? "Sign In"
                  : "Create Account"}
              </button>
            </form>

            {/* Demo admin hint */}
            {tab === "login" && (
              <div className="mt-5 bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-500">
                <span className="font-semibold text-slate-600">Demo admin: </span>
                admin@ecommerce.com / Admin1234!
              </div>
            )}
          </div>
        </div>

        <p className="text-center text-sm text-slate-400 mt-5">
          <Link to="/" className="hover:text-slate-600">← Back to Home</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
