// App.jsx
// Root component. Wraps everything in Context providers,
// mounts the Navbar, and declares all React Router routes.

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";

// Pages
import Home from "./pages/Home";
import ProductListing from "./pages/ProductListing";
import ProductDetails from "./pages/ProductDetails";
import Cart from "./pages/Cart";
import Login from "./pages/Login";
import AdminPanel from "./pages/AdminPanel";

// ── 404 fallback ──────────────────────────────────────────────────────────────
const NotFound = () => (
  <div className="page-container text-center py-24">
    <p className="text-7xl font-extrabold text-slate-200">404</p>
    <h2 className="text-2xl font-bold text-slate-700 mt-3">Page Not Found</h2>
    <a href="/" className="btn-primary inline-block mt-6">Go Home</a>
  </div>
);

const App = () => {
  return (
    // AuthProvider wraps CartProvider so Cart can access auth state if needed
    <AuthProvider>
      <CartProvider>
        <Router>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes>
                {/* Public routes */}
                <Route path="/" element={<Home />} />
                <Route path="/products" element={<ProductListing />} />
                <Route path="/products/:id" element={<ProductDetails />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/login" element={<Login />} />

                {/* Admin-only route — protected at client AND server */}
                <Route
                  path="/admin"
                  element={
                    <ProtectedRoute adminOnly>
                      <AdminPanel />
                    </ProtectedRoute>
                  }
                />

                {/* Catch-all */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>

            {/* Footer */}
            <footer className="bg-white border-t border-slate-200 mt-12">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row
                              items-center justify-between gap-3 text-sm text-slate-400">
                <span>© {new Date().getFullYear()} ShopMERN. Built with React, Node.js & MongoDB.</span>
                <div className="flex gap-5">
                  <a href="/products" className="hover:text-slate-600">Products</a>
                  <a href="/cart" className="hover:text-slate-600">Cart</a>
                  <a href="/login" className="hover:text-slate-600">Login</a>
                </div>
              </div>
            </footer>
          </div>
        </Router>
      </CartProvider>
    </AuthProvider>
  );
};

export default App;
