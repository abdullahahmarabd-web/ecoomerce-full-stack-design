// pages/Home.jsx
// Landing page: hero section + featured products grid (first 4 products).

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { useCart } from "../context/CartContext";

// ── Reusable Product Card ─────────────────────────────────────────────────────
const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  return (
    <div className="product-card group">
      <Link to={`/products/${product._id}`}>
        <div className="aspect-square overflow-hidden bg-slate-100">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              e.target.src = "https://placehold.co/400x400?text=No+Image";
            }}
          />
        </div>
      </Link>
      <div className="p-4">
        <span className="text-xs font-semibold text-brand-600 uppercase tracking-wide">
          {product.category}
        </span>
        <Link to={`/products/${product._id}`}>
          <h3 className="mt-1 font-semibold text-slate-800 hover:text-brand-600 transition-colors line-clamp-2">
            {product.name}
          </h3>
        </Link>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-lg font-bold text-slate-900">
            ${product.price.toFixed(2)}
          </span>
          <button
            onClick={() => addToCart(product)}
            disabled={product.stock === 0}
            className="btn-primary text-xs py-1.5 px-3 disabled:opacity-40"
          >
            {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ── Home Page ─────────────────────────────────────────────────────────────────
const Home = () => {
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const { data } = await axios.get("/api/products?limit=4");
        setFeatured(data.products);
      } catch (err) {
        console.error("Failed to load featured products:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchFeatured();
  }, []);

  return (
    <main>
      {/* ── Hero Section ── */}
      <section className="relative bg-gradient-to-br from-brand-900 via-brand-700 to-brand-500 text-white overflow-hidden">
        {/* Decorative background circles */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/4" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <div className="max-w-2xl">
            <span className="inline-block bg-white/10 backdrop-blur-sm border border-white/20 text-white/90
                             text-xs font-semibold uppercase tracking-widest px-3 py-1 rounded-full mb-5">
              New Season Arrivals
            </span>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold leading-tight tracking-tight">
              Shop the products
              <br />
              <span className="text-brand-100">you actually need</span>
            </h1>
            <p className="mt-5 text-lg text-white/75 max-w-lg leading-relaxed">
              Curated electronics, fitness gear, kitchen essentials, and accessories.
              Quality guaranteed, delivered fast.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <Link to="/products" className="btn-primary bg-white text-brand-700 hover:bg-brand-50 text-base px-7 py-3">
                Shop All Products
              </Link>
              <Link to="/products?category=electronics" className="btn-secondary bg-transparent text-white border-white/40
                           hover:bg-white/10 text-base px-7 py-3">
                Browse Electronics
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Category Pills ── */}
      <section className="bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-hide">
            {["All", "Electronics", "Footwear", "Accessories", "Kitchen", "Fitness"].map(
              (cat) => (
                <Link
                  key={cat}
                  to={cat === "All" ? "/products" : `/products?category=${cat.toLowerCase()}`}
                  className="shrink-0 px-4 py-1.5 rounded-full border border-slate-200 text-sm font-medium
                             text-slate-600 hover:border-brand-500 hover:text-brand-600 transition-colors"
                >
                  {cat}
                </Link>
              )
            )}
          </div>
        </div>
      </section>

      {/* ── Featured Products ── */}
      <section className="page-container">
        <div className="flex items-center justify-between mb-7">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Featured Products</h2>
            <p className="text-sm text-slate-500 mt-1">Our most popular picks right now</p>
          </div>
          <Link to="/products" className="text-sm font-semibold text-brand-600 hover:text-brand-700">
            View all →
          </Link>
        </div>

        {loading ? (
          // Skeleton loader
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="product-card animate-pulse">
                <div className="aspect-square bg-slate-200" />
                <div className="p-4 space-y-3">
                  <div className="h-3 bg-slate-200 rounded w-1/3" />
                  <div className="h-4 bg-slate-200 rounded w-3/4" />
                  <div className="h-4 bg-slate-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {featured.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* ── Value Props Banner ── */}
      <section className="bg-slate-900 text-white mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[
              { icon: "🚚", title: "Free Shipping", desc: "On all orders over $50" },
              { icon: "🔄", title: "Easy Returns", desc: "30-day hassle-free returns" },
              { icon: "🔒", title: "Secure Checkout", desc: "Your data is always protected" },
            ].map(({ icon, title, desc }) => (
              <div key={title} className="flex flex-col items-center gap-2">
                <span className="text-3xl">{icon}</span>
                <h3 className="font-semibold text-white">{title}</h3>
                <p className="text-sm text-slate-400">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

export default Home;
