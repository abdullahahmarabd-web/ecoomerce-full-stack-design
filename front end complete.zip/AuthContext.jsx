// context/AuthContext.jsx
// Provides authentication state globally: user object, token, login/logout.
// Token is persisted to localStorage so sessions survive page refresh.

import { createContext, useContext, useState, useCallback } from "react";
import axios from "axios";

const AuthContext = createContext(null);

// ── Helper: read persisted auth from localStorage ─────────────────────────────
const loadAuthFromStorage = () => {
  try {
    const stored = localStorage.getItem("auth");
    return stored ? JSON.parse(stored) : { user: null, token: null };
  } catch {
    return { user: null, token: null };
  }
};

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(loadAuthFromStorage);

  // Set axios default Authorization header whenever auth changes
  if (auth.token) {
    axios.defaults.headers.common["Authorization"] = `Bearer ${auth.token}`;
  } else {
    delete axios.defaults.headers.common["Authorization"];
  }

  // ── login ──────────────────────────────────────────────────────────────────
  // Called after a successful /api/auth/login response.
  const login = useCallback((userData) => {
    const newAuth = { user: userData, token: userData.token };
    setAuth(newAuth);
    localStorage.setItem("auth", JSON.stringify(newAuth));
    axios.defaults.headers.common["Authorization"] = `Bearer ${userData.token}`;
  }, []);

  // ── logout ─────────────────────────────────────────────────────────────────
  const logout = useCallback(() => {
    setAuth({ user: null, token: null });
    localStorage.removeItem("auth");
    delete axios.defaults.headers.common["Authorization"];
  }, []);

  const value = {
    user: auth.user,
    token: auth.token,
    isAuthenticated: !!auth.token,
    isAdmin: auth.user?.isAdmin === true,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// ── Custom hook ───────────────────────────────────────────────────────────────
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside <AuthProvider>");
  return context;
};
