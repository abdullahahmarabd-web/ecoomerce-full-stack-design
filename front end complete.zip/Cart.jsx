// pages/Cart.jsx
// Full cart page: item list, quantity controls, subtotals, order total, clear.

import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice } =
    useCart();

  if (cartItems.length === 0) {
    return (
      <div className="page-container text-center py-24">
        <p className="text-6xl mb-5">🛒</p>
        <h2 className="text-2xl font-bold text-slate-800">Your cart is empty</h2>
        <p className="text-slate-400 mt-2">Add some products to get started.</p>
        <Link to="/products" className="btn-primary inline-block mt-6">
          Browse Products
        </Link>
      </div>
    );
  }

  // Estimated tax (10%)
  const tax = totalPrice * 0.1;
  const grandTotal = totalPrice + tax;

  return (
    <div className="page-container">
      {/* ── Header ── */}
      <div className="flex items-center justify-between mb-7">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Shopping Cart</h1>
          <p className="text-slate-400 mt-1">{totalItems} item{totalItems !== 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={clearCart}
          className="text-sm text-red-500 hover:text-red-700 font-medium transition-colors"
        >
          Clear cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

        {/* ── Cart Items ── */}
        <div className="lg:col-span-2 space-y-4">
          {cartItems.map((item) => (
            <div
              key={item._id}
              className="bg-white rounded-2xl border border-slate-200 p-4 flex gap-4"
            >
              {/* Thumbnail */}
              <Link to={`/products/${item._id}`} className="shrink-0">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-xl bg-slate-100"
                  onError={(e) => { e.target.src = "https://placehold.co/100x100?text=?"; }}
                />
              </Link>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-semibold text-brand-600 uppercase tracking-wide">
                      {item.category}
                    </span>
                    <Link to={`/products/${item._id}`}>
                      <h3 className="font-semibold text-slate-800 hover:text-brand-600 transition-colors line-clamp-2 mt-0.5">
                        {item.name}
                      </h3>
                    </Link>
                  </div>
                  {/* Remove button */}
                  <button
                    onClick={() => removeFromCart(item._id)}
                    className="shrink-0 text-slate-300 hover:text-red-500 transition-colors p-1"
                    aria-label="Remove item"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>

                {/* Price + quantity row */}
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
                    <button
                      onClick={() => updateQuantity(item._id, item.quantity - 1)}
                      className="px-2.5 py-1 text-slate-500 hover:bg-slate-100 transition-colors font-bold text-sm"
                    >
                      −
                    </button>
                    <span className="px-3 py-1 text-sm font-semibold text-slate-700 border-x border-slate-200">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item._id, item.quantity + 1)}
                      disabled={item.quantity >= item.stock}
                      className="px-2.5 py-1 text-slate-500 hover:bg-slate-100 transition-colors font-bold text-sm
                                 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      +
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                    <p className="text-xs text-slate-400">${item.price.toFixed(2)} each</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Order Summary ── */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sticky top-24">
            <h2 className="text-lg font-bold text-slate-900 mb-5">Order Summary</h2>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal ({totalItems} item{totalItems !== 1 ? "s" : ""})</span>
                <span className="font-medium text-slate-800">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Estimated Tax (10%)</span>
                <span className="font-medium text-slate-800">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Shipping</span>
                <span className="text-green-600 font-medium">
                  {totalPrice >= 50 ? "Free" : "$5.99"}
                </span>
              </div>
              {totalPrice < 50 && (
                <p className="text-xs text-slate-400 bg-slate-50 rounded-lg p-2.5">
                  Add ${(50 - totalPrice).toFixed(2)} more for free shipping.
                </p>
              )}
            </div>

            <hr className="my-5 border-slate-200" />

            <div className="flex justify-between font-bold text-lg text-slate-900">
              <span>Total</span>
              <span>
                ${(grandTotal + (totalPrice < 50 ? 5.99 : 0)).toFixed(2)}
              </span>
            </div>

            <button className="btn-primary w-full mt-5 py-3 text-base">
              Proceed to Checkout
            </button>

            <Link
              to="/products"
              className="block text-center text-sm text-brand-600 hover:text-brand-700 font-medium mt-4"
            >
              ← Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
