// pages/AdminPanel.jsx
// Admin dashboard: product table + create/edit/delete form.
// Protected client-side by ProtectedRoute and server-side by adminOnly middleware.

import { useState, useEffect, useCallback } from "react";
import axios from "axios";

// ── Empty form state factory ──────────────────────────────────────────────────
const emptyForm = () => ({
  name: "",
  price: "",
  image: "",
  description: "",
  category: "",
  stock: "",
  id: "",
});

// ── Admin Panel ───────────────────────────────────────────────────────────────
const AdminPanel = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formMode, setFormMode] = useState(null); // null | "create" | "edit"
  const [formData, setFormData] = useState(emptyForm());
  const [editingId, setEditingId] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(null); // { type: "success"|"error", message }
  const [deleteConfirm, setDeleteConfirm] = useState(null); // product._id to confirm

  // ── Fetch all products ────────────────────────────────────────────────────
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await axios.get("/api/products?limit=100");
      setProducts(data.products);
    } catch {
      showFeedback("error", "Failed to load products.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  // ── Feedback helper ───────────────────────────────────────────────────────
  const showFeedback = (type, message) => {
    setFeedback({ type, message });
    setTimeout(() => setFeedback(null), 4000);
  };

  // ── Form handlers ─────────────────────────────────────────────────────────
  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const openCreate = () => {
    setFormData(emptyForm());
    setEditingId(null);
    setFormMode("create");
  };

  const openEdit = (product) => {
    setFormData({
      name: product.name,
      price: product.price,
      image: product.image,
      description: product.description,
      category: product.category,
      stock: product.stock,
      id: product.id || "",
    });
    setEditingId(product._id);
    setFormMode("edit");
    // Scroll to form
    setTimeout(() => document.getElementById("product-form")?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  const closeForm = () => {
    setFormMode(null);
    setFormData(emptyForm());
    setEditingId(null);
  };

  // ── Submit (create or update) ─────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    const payload = {
      ...formData,
      price: Number(formData.price),
      stock: Number(formData.stock),
    };

    try {
      if (formMode === "create") {
        await axios.post("/api/products", payload);
        showFeedback("success", "Product created successfully.");
      } else {
        await axios.put(`/api/products/${editingId}`, payload);
        showFeedback("success", "Product updated successfully.");
      }
      closeForm();
      fetchProducts();
    } catch (err) {
      showFeedback("error", err.response?.data?.message || "Operation failed.");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Delete ────────────────────────────────────────────────────────────────
  const handleDelete = async (productId) => {
    try {
      await axios.delete(`/api/products/${productId}`);
      showFeedback("success", "Product deleted.");
      setDeleteConfirm(null);
      fetchProducts();
    } catch (err) {
      showFeedback("error", err.response?.data?.message || "Delete failed.");
    }
  };

  // ── UI ────────────────────────────────────────────────────────────────────
  return (
    <div className="page-container space-y-8">

      {/* ── Header ── */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Admin Panel</h1>
          <p className="text-slate-400 mt-1">{products.length} products in the catalog</p>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Add Product
        </button>
      </div>

      {/* ── Feedback Banner ── */}
      {feedback && (
        <div
          className={`rounded-xl px-5 py-3 text-sm font-medium ${
            feedback.type === "success"
              ? "bg-green-50 border border-green-200 text-green-700"
              : "bg-red-50 border border-red-200 text-red-700"
          }`}
        >
          {feedback.message}
        </div>
      )}

      {/* ── Product Table ── */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="px-6 py-4 border-b border-slate-100">
          <h2 className="font-semibold text-slate-700">Product Catalog</h2>
        </div>

        {loading ? (
          <div className="p-10 text-center text-slate-400">Loading products...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="px-5 py-3">Product</th>
                  <th className="px-5 py-3">Category</th>
                  <th className="px-5 py-3">Price</th>
                  <th className="px-5 py-3">Stock</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((product) => (
                  <tr key={product._id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                          onError={(e) => { e.target.src = "https://placehold.co/40x40?text=?"; }}
                        />
                        <span className="font-medium text-slate-800 line-clamp-1 max-w-xs">
                          {product.name}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span className="bg-brand-50 text-brand-700 text-xs font-semibold px-2 py-1 rounded-full capitalize">
                        {product.category}
                      </span>
                    </td>
                    <td className="px-5 py-3 font-semibold text-slate-800">
                      ${product.price.toFixed(2)}
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className={`font-medium ${
                          product.stock === 0
                            ? "text-red-600"
                            : product.stock <= 10
                            ? "text-yellow-600"
                            : "text-green-600"
                        }`}
                      >
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEdit(product)}
                          className="text-xs font-medium text-brand-600 hover:text-brand-800 px-3 py-1.5
                                     border border-brand-200 rounded-lg hover:bg-brand-50 transition-colors"
                        >
                          Edit
                        </button>
                        {deleteConfirm === product._id ? (
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-slate-500">Confirm?</span>
                            <button
                              onClick={() => handleDelete(product._id)}
                              className="text-xs font-medium text-white bg-red-600 hover:bg-red-700 px-3 py-1.5 rounded-lg transition-colors"
                            >
                              Yes
                            </button>
                            <button
                              onClick={() => setDeleteConfirm(null)}
                              className="text-xs font-medium text-slate-600 hover:text-slate-800 px-3 py-1.5
                                         border border-slate-200 rounded-lg transition-colors"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirm(product._id)}
                            className="text-xs font-medium text-red-600 hover:text-red-800 px-3 py-1.5
                                       border border-red-200 rounded-lg hover:bg-red-50 transition-colors"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {products.length === 0 && (
              <p className="text-center text-slate-400 py-12">
                No products yet. Add your first one above.
              </p>
            )}
          </div>
        )}
      </div>

      {/* ── Create / Edit Form ── */}
      {formMode && (
        <div id="product-form" className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <h2 className="font-semibold text-slate-800">
              {formMode === "create" ? "Add New Product" : "Edit Product"}
            </h2>
            <button onClick={closeForm} className="text-slate-400 hover:text-slate-600">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Name */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Product Name <span className="text-red-500">*</span>
                </label>
                <input
                  name="name" value={formData.name} onChange={handleChange}
                  required placeholder="e.g. Wireless Headphones Pro"
                  className="form-input"
                />
              </div>

              {/* Price */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Price ($) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number" name="price" value={formData.price} onChange={handleChange}
                  required min="0" step="0.01" placeholder="0.00"
                  className="form-input"
                />
              </div>

              {/* Stock */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Stock Quantity <span className="text-red-500">*</span>
                </label>
                <input
                  type="number" name="stock" value={formData.stock} onChange={handleChange}
                  required min="0" placeholder="0"
                  className="form-input"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  name="category" value={formData.category} onChange={handleChange}
                  required className="form-input"
                >
                  <option value="">Select a category</option>
                  {["electronics", "footwear", "accessories", "kitchen", "fitness", "other"].map(
                    (c) => (
                      <option key={c} value={c} className="capitalize">
                        {c.charAt(0).toUpperCase() + c.slice(1)}
                      </option>
                    )
                  )}
                </select>
              </div>

              {/* External ID */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  External SKU / ID
                  <span className="text-slate-400 font-normal ml-1">(optional)</span>
                </label>
                <input
                  name="id" value={formData.id} onChange={handleChange}
                  placeholder="e.g. SKU-12345"
                  className="form-input"
                />
              </div>

              {/* Image URL */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Image URL <span className="text-red-500">*</span>
                </label>
                <input
                  name="image" value={formData.image} onChange={handleChange}
                  required placeholder="https://example.com/image.jpg"
                  className="form-input"
                />
                {formData.image && (
                  <img
                    src={formData.image}
                    alt="Preview"
                    className="mt-2 w-20 h-20 object-cover rounded-lg border border-slate-200"
                    onError={(e) => { e.target.style.display = "none"; }}
                  />
                )}
              </div>

              {/* Description */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  name="description" value={formData.description} onChange={handleChange}
                  required rows={4} placeholder="Describe the product..."
                  className="form-input resize-none"
                />
              </div>
            </div>

            {/* Form actions */}
            <div className="flex items-center gap-3 mt-6 pt-5 border-t border-slate-100">
              <button type="submit" disabled={submitting} className="btn-primary px-7 py-2.5">
                {submitting
                  ? "Saving..."
                  : formMode === "create"
                  ? "Create Product"
                  : "Save Changes"}
              </button>
              <button type="button" onClick={closeForm} className="btn-secondary px-7 py-2.5">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
