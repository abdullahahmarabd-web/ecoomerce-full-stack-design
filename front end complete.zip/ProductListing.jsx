// pages/ProductListing.jsx
// Displays all products from the API in a responsive grid.
// Search bar filters by name/category via API query param (debounced).
// Category pills provide one-click filtering.
// Reads initial ?category= from the URL so Home page links work directly.

import { useState, useEffect, useCallback } from "react";
import { Link, useSearchParams } from "react-router-dom";
import axios from "axios";
import { useCart } from "../context/CartContext";

// ── Product Card ──────────────────────────────────────────────────────────────
const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const inStock = product.stock > 0;

  return (
    <div className="product-card group flex flex-col">
      <Link to={`/products/${product._id}`} className="block">
        <div className="aspect-square overflow-hidden bg-slate-100 relative">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => { e.target.src = "https://placehold.co/400x400?text=No+Image"; }}
          />
          {!inStock && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <span className="bg-white text-slate-700 text-xs font-bold px-3 py-1 rounded-full">
                Out of Stock
              </span>
            </div>
          )}
        </div>
      </Link>

      <div className="p-4 flex flex-col flex-1">
        <span className="text-xs font-semibold text-brand-600 uppercase tracking-wide">
          {product.category}
        </span>
        <Link to={`/products/${product._id}`}>
          <h3 className="mt-1 font-semibold text-slate-800 hover:text-brand-600 transition-colors line-clamp-2 flex-1">
            {product.name}
          </h3>
        </Link>
        <p className="text-xs text-slate-400 mt-1 line-clamp-2">{product.description}</p>

        <div className="mt-4 flex items-center justify-between">
          <span className="text-lg font-bold text-slate-900">${product.price.toFixed(2)}</span>
          <button
            onClick={() => addToCart(product)}
            disabled={!inStock}
            className="btn-primary text-xs py-1.5 px-3"
          >
            {inStock ? "Add to Cart" : "Unavailable"}
          </button>
        </div>
      </div>
    </div>
  );
};

const CATEGORIES = ["All", "Electronics", "Footwear", "Accessories", "Kitchen", "Fitness"];

// ── Product Listing Page ──────────────────────────────────────────────────────
const ProductListing = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [searchInput, setSearchInput] = useState("");

  // Read initial filters from URL
  const activeCategory = searchParams.get("category") || "";
  const activeSearch = searchParams.get("search") || "";

  // ── Fetch products whenever URL params change ───────────────────────────────
  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (activeSearch) params.set("search", activeSearch);
        if (activeCategory) params.set("category", activeCategory);
        params.set("limit", "50");

        const { data } = await axios.get(`/api/products?${params.toString()}`);
        setProducts(data.products);
        setTotal(data.total);
      } catch (err) {
        console.error("Failed to load products:", err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [activeSearch, activeCategory]);

  // Sync search input with URL param on mount
  useEffect(() => {
    setSearchInput(activeSearch);
  }, []); // eslint-disable-line

  // ── Debounced search — update URL after 400ms idle ─────────────────────────
  useEffect(() => {
    const timer = setTimeout(() => {
      const next = new URLSearchParams(searchParams);
      if (searchInput) {
        next.set("search", searchInput);
      } else {
        next.delete("search");
      }
      setSearchParams(next, { replace: true });
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]); // eslint-disable-line

  const handleCategoryClick = useCallback(
    (cat) => {
      const next = new URLSearchParams();
      if (cat && cat !== "All") next.set("category", cat.toLowerCase());
      if (searchInput) next.set("search", searchInput);
      setSearchParams(next);
    },
    [searchInput, setSearchParams]
  );

  const clearFilters = () => {
    setSearchInput("");
    setSearchParams({});
  };

  const hasFilters = activeSearch || activeCategory;

  return (
    <div className="page-container">
      {/* ── Page Header ── */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900">All Products</h1>
        <p className="text-slate-500 mt-1">
          {loading ? "Loading..." : `${total} product${total !== 1 ? "s" : ""} found`}
        </p>
      </div>

      {/* ── Search + Filter Bar ── */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6 space-y-4">
        {/* Search input */}
        <div className="relative">
          <svg
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"
            fill="none" stroke="currentColor" viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search products by name, category, or description..."
            className="form-input pl-10 pr-10"
          />
          {searchInput && (
            <button
              onClick={() => setSearchInput("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category pills */}
        <div className="flex items-center gap-2 flex-wrap">
          {CATEGORIES.map((cat) => {
            const isActive =
              cat === "All"
                ? !activeCategory
                : activeCategory === cat.toLowerCase();
            return (
              <button
                key={cat}
                onClick={() => handleCategoryClick(cat)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                  isActive
                    ? "bg-brand-600 text-white border-brand-600"
                    : "border-slate-200 text-slate-600 hover:border-brand-400 hover:text-brand-600"
                }`}
              >
                {cat}
              </button>
            );
          })}
          {hasFilters && (
            <button
              onClick={clearFilters}
              className="ml-auto text-xs text-slate-400 hover:text-red-500 transition-colors"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* ── Product Grid ── */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="product-card animate-pulse">
              <div className="aspect-square bg-slate-200" />
              <div className="p-4 space-y-3">
                <div className="h-3 bg-slate-200 rounded w-1/3" />
                <div className="h-4 bg-slate-200 rounded w-3/4" />
                <div className="h-8 bg-slate-200 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-5xl mb-4">🔍</p>
          <h3 className="text-lg font-semibold text-slate-700">No products found</h3>
          <p className="text-slate-400 mt-1">Try a different search term or category.</p>
          <button onClick={clearFilters} className="btn-primary mt-5">
            Show all products
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {products.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductListing;
