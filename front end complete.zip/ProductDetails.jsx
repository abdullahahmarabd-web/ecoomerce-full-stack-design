// pages/ProductDetails.jsx
// Single product view: split image/details layout.
// Shows stock status, description, price, quantity picker, and Add to Cart.

import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { useCart } from "../context/CartContext";

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, cartItems } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  // How many of this item is already in the cart
  const inCart = cartItems.find((i) => i._id === product?._id)?.quantity || 0;
  const maxCanAdd = product ? Math.max(0, product.stock - inCart) : 0;

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      setError(null);
      try {
        const { data } = await axios.get(`/api/products/${id}`);
        setProduct(data);
      } catch (err) {
        setError(err.response?.data?.message || "Product not found.");
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (!product || maxCanAdd === 0) return;
    addToCart(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  // ── Loading skeleton ───────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="page-container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-pulse">
          <div className="aspect-square bg-slate-200 rounded-2xl" />
          <div className="space-y-4 pt-4">
            <div className="h-4 bg-slate-200 rounded w-1/4" />
            <div className="h-8 bg-slate-200 rounded w-3/4" />
            <div className="h-6 bg-slate-200 rounded w-1/4" />
            <div className="h-24 bg-slate-200 rounded" />
          </div>
        </div>
      </div>
    );
  }

  // ── Error state ────────────────────────────────────────────────────────────
  if (error || !product) {
    return (
      <div className="page-container text-center py-20">
        <p className="text-5xl mb-4">😕</p>
        <h2 className="text-xl font-semibold text-slate-700">{error || "Product not found"}</h2>
        <button onClick={() => navigate("/products")} className="btn-primary mt-5">
          Back to Products
        </button>
      </div>
    );
  }

  const inStock = product.stock > 0;

  return (
    <div className="page-container">
      {/* ── Breadcrumb ── */}
      <nav className="flex items-center gap-2 text-sm text-slate-400 mb-7">
        <Link to="/" className="hover:text-slate-600">Home</Link>
        <span>/</span>
        <Link to="/products" className="hover:text-slate-600">Products</Link>
        <span>/</span>
        <span className="text-slate-700 font-medium truncate max-w-xs">{product.name}</span>
      </nav>

      {/* ── Split Layout ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 lg:gap-16">

        {/* Left — Image */}
        <div className="relative">
          <div className="aspect-square rounded-2xl overflow-hidden bg-slate-100 shadow-sm">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              onError={(e) => { e.target.src = "https://placehold.co/600x600?text=No+Image"; }}
            />
          </div>
          {!inStock && (
            <div className="absolute inset-0 rounded-2xl bg-black/40 flex items-center justify-center">
              <span className="bg-white text-slate-700 font-bold px-5 py-2 rounded-full text-sm">
                Out of Stock
              </span>
            </div>
          )}
        </div>

        {/* Right — Product Details */}
        <div className="flex flex-col py-2">
          {/* Category badge */}
          <span className="inline-flex items-center gap-1.5 self-start bg-brand-50 text-brand-700
                           text-xs font-semibold uppercase tracking-wide px-3 py-1 rounded-full border border-brand-100">
            {product.category}
          </span>

          {/* Name */}
          <h1 className="mt-3 text-3xl font-extrabold text-slate-900 leading-tight">
            {product.name}
          </h1>

          {/* Price */}
          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-4xl font-bold text-slate-900">
              ${product.price.toFixed(2)}
            </span>
          </div>

          {/* Stock status */}
          <div className="mt-4 flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                product.stock > 10
                  ? "bg-green-500"
                  : product.stock > 0
                  ? "bg-yellow-500"
                  : "bg-red-500"
              }`}
            />
            <span
              className={`text-sm font-medium ${
                product.stock > 10
                  ? "text-green-700"
                  : product.stock > 0
                  ? "text-yellow-700"
                  : "text-red-700"
              }`}
            >
              {product.stock > 10
                ? `In Stock (${product.stock} available)`
                : product.stock > 0
                ? `Low Stock — only ${product.stock} left`
                : "Out of Stock"}
            </span>
          </div>

          {/* Divider */}
          <hr className="my-5 border-slate-200" />

          {/* Description */}
          <div>
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-2">
              Description
            </h2>
            <p className="text-slate-700 leading-relaxed">{product.description}</p>
          </div>

          {/* Divider */}
          <hr className="my-5 border-slate-200" />

          {/* Quantity + Add to Cart */}
          {inStock && (
            <div className="flex items-center gap-4 flex-wrap">
              {/* Quantity stepper */}
              <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 transition-colors font-bold"
                >
                  −
                </button>
                <span className="px-4 py-2 font-semibold text-slate-800 text-sm border-x border-slate-300">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => Math.min(maxCanAdd, q + 1))}
                  disabled={quantity >= maxCanAdd}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 transition-colors font-bold
                             disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  +
                </button>
              </div>

              {/* Add to Cart button */}
              <button
                onClick={handleAddToCart}
                disabled={maxCanAdd === 0}
                className={`flex-1 sm:flex-none btn-primary py-3 px-8 text-base transition-all ${
                  added ? "bg-green-600 hover:bg-green-600" : ""
                }`}
              >
                {added ? "✓ Added to Cart" : maxCanAdd === 0 ? "Cart Full" : "Add to Cart"}
              </button>
            </div>
          )}

          {inCart > 0 && (
            <p className="mt-3 text-sm text-slate-500">
              {inCart} already in your cart.{" "}
              <Link to="/cart" className="text-brand-600 font-medium hover:underline">
                View cart →
              </Link>
            </p>
          )}

          {/* SKU / ID if present */}
          {product.id && (
            <p className="mt-5 text-xs text-slate-400">SKU: {product.id}</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
